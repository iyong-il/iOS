//
//  Rps.swift
//  RPSGame
//
//  Created by Allen H on 2021/05/21.
//

import Foundation

enum Rps: Int {
    case rock
    case paper
    case scissors
}
